# ElasticSuite Virtual Category Functional Tests

The Functional Test Module for **ElasticSuite Virtual Category** module.
